from django.shortcuts import render, get_object_or_404, redirect
from .models import Food, Menu, Cart
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.forms import AuthenticationForm
from .forms import SignUpForm
from django.contrib.auth.decorators import login_required


def home(request):
    query = request.GET.get('q', '')  # Get search query
    menus = Menu.objects.all()  # Get all menus
    foods = Food.objects.filter(name__icontains=query) if query else Food.objects.all()

    return render(request, 'home.html', {'foods': foods, 'menus': menus, 'query': query})

def food_list(request):
    query = request.GET.get('q', '')  # Get search query
    menu_slug = request.GET.get('menu')  # Get menu filter from URL query params
    menus = Menu.objects.all()  # Get all menus

    if menu_slug:
        selected_menu = get_object_or_404(Menu, slug=menu_slug)
        foods = Food.objects.filter(menu=selected_menu)
    else:
        selected_menu = None
        foods = Food.objects.all()  # Show all foods if no menu is selected

    # Apply search filter if query exists
    if query:
        foods = foods.filter(name__icontains=query)  # Filter foods by name

    context = {
        'menus': menus,
        'foods': foods,
        'selected_menu': selected_menu,
        'query': query
    }
    return render(request, 'food_list.html', context)

def food_page(request, slug):
    food = get_object_or_404(Food, slug=slug)
    menus = Menu.objects.all() 

    context = {
        'food': food,
        'menus': menus,  
    }
    return render(request, 'food_page.html', context)


@login_required
def cart_detail(request):
    """Display the cart page (Only for logged-in users)"""
    cart = Cart.objects.filter(user=request.user).last()  # Get the last cart for the user
    cart_foods = cart.get_items() if cart else []
    total_price = cart.total_price() if cart else 0.0

    context = {
        'cart': cart,
        'cart_foods': cart_foods,
        'total_price': total_price,
    }

    return render(request, 'cart.html', context)

# Add food to the cart and stay on the same page
@login_required
def add_to_cart(request, food_id):
    """Add food item to cart and stay on the same page"""
    food = get_object_or_404(Food, id=food_id)
    
    # Get the quantity from the POST request (default to 1 if not specified)
    quantity = int(request.POST.get('quantity', 1))  # Default quantity is 1 if not provided

    # Get or create a cart for the logged-in user
    cart, created = Cart.objects.get_or_create(user=request.user)

    # Add the food item to the cart with the specified quantity
    cart.add(food, quantity=quantity)
    
    return redirect(request.META.get('HTTP_REFERER', 'food_list'))

# Remove food item from the cart
@login_required
def remove_from_cart(request, food_id):
    """Remove food item from cart"""
    food = get_object_or_404(Food, id=food_id)

    # Get the cart for the logged-in user
    cart = Cart.objects.filter(user=request.user).last()
    if cart:
        cart.remove(food)

    return redirect('cart_detail')

# Clear the cart
@login_required
def clear_cart(request):
    """Clear the cart"""
    # Get the cart for the logged-in user
    cart = Cart.objects.filter(user=request.user).last()
    if cart:
        cart.clear()

    return redirect('cart_detail')

def signup_view(request):
    """Handles user sign-up"""
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('home')  # Redirect to home page
    else:
        form = SignUpForm()
    return render(request, 'signup.html', {'form': form, 'hide_footer': True})


def login_view(request):
    """Handles user login"""
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')  # Redirect to home
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form, 'hide_footer': True})

def logout_view(request):
    """Handles user logout"""
    logout(request)
    return redirect('home')
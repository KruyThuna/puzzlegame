from django.urls import path
from . import views

urlpatterns = [
    # Home page
    path('', views.home, name='home'),

    # Food-related URLs
    path('foods/', views.food_list, name='food_list'),  # List all foods
    path('foods/<slug:slug>/', views.food_page, name='food_page'),  # Food details

    # Cart-related URLs
    path('cart/', views.cart_detail, name='cart_detail'),  # View cart
    path('cart/add/<int:food_id>/', views.add_to_cart, name='add_to_cart'),  # Add food to cart
    path('cart/remove/<int:food_id>/', views.remove_from_cart, name='remove_from_cart'),  # Remove food from cart
    path('cart/clear/', views.clear_cart, name='clear_cart'),  # Clear all items from cart

    # Authentication URLs
    path('signup/', views.signup_view, name='signup'),  # User signup
    path('login/', views.login_view, name='login'),  # User login
    path('logout/', views.logout_view, name='logout'),  # User logout
]

from django.contrib import admin
from .models import Menu, Food, Cart, CartFood

# Customizing the Menu Model Admin
class MenuAdmin(admin.ModelAdmin):
    list_display = ('name', 'slug', 'image')  # Display fields in the list view
    prepopulated_fields = {'slug': ('name',)}  # Automatically populate slug from name
    search_fields = ('name',)  # Enable search by name
    ordering = ('name',)  # Default ordering by name

# Customizing the Food Model Admin
class FoodAdmin(admin.ModelAdmin):
    list_display = ('name', 'menu', 'price', 'description', 'image', 'slug')  # Fields to display
    list_filter = ('menu',)  # Filter by menu
    search_fields = ('name', 'description', 'slug')  # Enable search by name, description, and slug
    prepopulated_fields = {'slug': ('name',)}  # Automatically populate slug from name
    ordering = ('name',)  # Default ordering by name

# Customizing the CartFood Model Admin
class CartFoodAdmin(admin.ModelAdmin):
    list_display = ('food', 'cart', 'quantity', 'added_at')  # Fields to display
    list_filter = ('cart', 'food')  # Filter by cart and food
    search_fields = ('food__name', 'cart__user__username')  # Search by food name and user name
    ordering = ('added_at',)  # Default ordering by added_at (date added to cart)

# Customizing the Cart Model Admin
class CartAdmin(admin.ModelAdmin):
    list_display = ('user', 'created_at', 'updated_at')  # Fields to display
    list_filter = ('user',)  # Filter by user
    search_fields = ('user__username',)  # Enable search by user name
    ordering = ('-created_at',)  # Default ordering by created_at (newest first)

# Registering the models to the admin interface
admin.site.register(Menu, MenuAdmin)
admin.site.register(Food, FoodAdmin)
admin.site.register(Cart, CartAdmin)
admin.site.register(CartFood, CartFoodAdmin)

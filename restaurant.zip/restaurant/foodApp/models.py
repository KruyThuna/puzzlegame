from django.db import models
from django.contrib.auth.models import User
from decimal import Decimal

class Menu(models.Model):
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True)  # SlugField with unique constraint
    image = models.ImageField(default='empty.png', blank=True, upload_to='images/')  # Ensure MEDIA settings
    

    def __str__(self):
        return self.name

class Food(models.Model):
    name = models.CharField(max_length=255)
    slug = models.SlugField(max_length=255, unique=True)  # Added max_length for consistency
    menu = models.ForeignKey(Menu, on_delete=models.SET_NULL, null=True, related_name="foods")
    price = models.DecimalField(max_digits=10, decimal_places=2)  # More precise than FloatField
    description = models.TextField()
    image = models.ImageField(default='empty.png', blank=True, upload_to='images/')  # Ensure MEDIA settings

    def __str__(self):
        return f"{self.name} ({self.menu.name if self.menu else 'No menu'})"
    

class Cart(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE, related_name="carts", null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Cart for {self.user.username if self.user else 'Guest'}"

    def total_price(self):
        """Calculate the total price of all items in the cart."""
        total = sum(item.total_price() for item in self.items.all())
        return total

    def add(self, food, quantity=1):
        cart_item, created = CartFood.objects.get_or_create(cart=self, food=food)

        if not created:
            cart_item.quantity += quantity
        else:
            cart_item.quantity = quantity

        cart_item.save()



    def remove(self, food):
        """Remove a food item from the cart"""
        cart_item = CartFood.objects.filter(cart=self, food=food).first()
        if cart_item:
            cart_item.delete()

    def get_items(self):
        """Get all items in the cart"""
        return self.items.all()

    def clear(self):
        """Remove all items from the cart"""
        self.items.all().delete()


# CartFood Model
class CartFood(models.Model):
    cart = models.ForeignKey(Cart, on_delete=models.CASCADE, related_name="items")
    food = models.ForeignKey(Food, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)
    added_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.food.name} ({self.quantity})"

    def total_price(self):
        """Calculate the total price for this item (food price * quantity)."""
        return Decimal(self.food.price) * self.quantity
